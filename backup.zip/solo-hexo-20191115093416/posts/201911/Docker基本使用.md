title: Docker基本使用
date: '2019-11-08 09:26:58'
updated: '2019-11-08 09:26:58'
tags: [docker]
permalink: /articles/2019/11/08/1573176418298.html
---
<h1 id="docker架构">docker架构</h1>

![image.png](https://img.hacpai.com/file/2019/11/image-0808f562.png)


#### (1) Docker daemon（Docker守护进程）

Docker daemon是一个运行在宿主机（DOCKER_HOST）的后台进程。我们可通过Docker客户端与之通信。

#### (2) Client（Docker客户端）

Docker客户端是Docker的用户界面，它可以接受用户命令和配置标识，并与Docker daemon通信。图中，docker build等都是Docker的相关命令。

#### (3) Images（Docker镜像）

Docker镜像是一个只读模板，它包含创建Docker容器的说明。它和系统安装光盘有点像——我们使用系统安装光盘安装系统，同理，我们使用Docker镜像运行Docker镜像中的程序。

#### (4) Container（容器）

容器是镜像的可运行实例。镜像和容器的关系有点类似于面向对象中，类和对象的关系。我们可通过Docker API或者CLI命令来启停、移动、删除容器。  
==最佳实践==:容器不应该向其存储层内写入任何数据，容器存储层要保持无状态化。所有的文件写入操作，都应该使用 数据卷（Volume）、或者绑定宿主目录，在这些位置的读写会跳过容器存储层，直接对宿主（或网络存储）发生读写，其性能和稳定性更高。

#### (5) Registry

Docker Registry是一个集中存储与分发镜像的服务。我们构建完Docker镜像后，就可在当前宿主机上运行。但如果想要在其他机器上运行这个镜像，我们就需要手动拷贝。此时，我们可借助Docker Registry来避免镜像的手动拷贝。

一个Docker Registry可包含多个Docker仓库；每个仓库可包含多个镜像标签；每个标签对应一个Docker镜像。这跟Maven的仓库有点类似，如果把Docker Registry比作Maven仓库的话，那么Docker仓库就可理解为某jar包的路径，而镜像标签则可理解为jar包的版本号。

Docker Registry可分为公有Docker Registry和私有Docker Registry。最常用的Docker Registry莫过于官方的Docker Hub，这也是默认的Docker Registry。Docker Hub上存放着大量优秀的镜像，我们可使用Docker命令下载并使用。

<h1 id="Docker与虚拟机">Docker与虚拟机</h1>

![image.png](https://img.hacpai.com/file/2019/11/image-67df9ae2.png)


#### 虚拟化粒度不同
1. 虚拟机利用Hypervisor虚拟化CPU、内存、IO设备等实现的，然后在其上运行完整的操作系统，再在该系统上运行所需的应用。资源隔离级别：OS级别
2. 运行在Docker容器中的应用直接运行于宿主机的内核，容器共享宿主机的内核，容器内部运行的是Linux副本，没有自己的内核，直接使用物理机的硬件资源，因此CPU/内存利用率上有一定优势。资源隔离级别：利用Linux内核本身支持的容器方式实现资源和环境隔离。

<h1 id="docker安装">docker安装</h1>

### 系统要求
Docker CE 支持 64 位版本 CentOS 7，并且要求内核版本不低于 3.10。 CentOS 7 满足最低内核的要求，但由于内核版本比较低，部分功能（如 overlay2 存储层驱动）无法使用，并且部分功能可能不太稳定。

### 卸载旧版本
旧版本的 Docker 称为 docker 或者 docker-engine，使用以下命令卸载旧版本：

```
$ sudo yum remove docker \
                  docker-client \
                  docker-client-latest \
                  docker-common \
                  docker-latest \
                  docker-latest-logrotate \
                  docker-logrotate \
                  docker-selinux \
                  docker-engine-selinux \
                  docker-engine
```

### 使用 yum 安装
执行以下命令安装依赖包：

```
$ sudo yum install -y yum-utils \
           device-mapper-persistent-data \
           lvm2
```
鉴于国内网络问题，强烈建议使用国内源，官方源请在注释中查看。
执行下面的命令添加 yum 软件源：

```
$ sudo yum-config-manager \
    --add-repo \
    https://mirrors.ustc.edu.cn/docker-ce/linux/centos/docker-ce.repo


# 官方源
# $ sudo yum-config-manager \
#     --add-repo \
#     https://download.docker.com/linux/centos/docker-ce.repo
```
如果需要测试版本的 Docker CE 请使用以下命令

```
$ sudo yum-config-manager --enable docker-ce-test
```
如果需要每日构建版本的 Docker CE 请使用以下命令：

```
$ sudo yum-config-manager --enable docker-ce-nightly
```
### 安装 Docker CE
更新 yum 软件源缓存，并安装 docker-ce

```
$ sudo yum makecache fast
$ sudo yum install docker-ce
```
### 使用脚本自动安装
在测试或开发环境中 Docker 官方为了简化安装流程，提供了一套便捷的安装脚本，CentOS 系统上可以使用这套脚本安装，另外可以通过 --mirror 选项使用国内源进行安装：

```
$ curl -fsSL get.docker.com -o get-docker.sh
$ sudo sh get-docker.sh --mirror Aliyun
# $ sudo sh get-docker.sh --mirror AzureChinaCloud
```
执行这个命令后，脚本就会自动的将一切准备工作做好，并且把 Docker CE 的稳定(stable)版本安装在系统中
### 启动 Docker CE
```
$ sudo systemctl enable docker
$ sudo systemctl start docker
```
### 建立 docker 用户组
默认情况下，docker 命令会使用 Unix socket 与 Docker 引擎通讯。而只有 root 用户和 docker 组的用户才可以访问 Docker 引擎的 Unix socket。出于安全考虑，一般 Linux 系统上不会直接使用 root 用户。因此，更好地做法是将需要使用 docker 的用户加入 docker 用户组。
建立 docker 组：

```
$ sudo groupadd docker
```

将当前用户加入 docker 组：

```
$ sudo usermod -aG docker $USER
```

退出当前终端并重新登录，进行如下测试。
测试 Docker 是否安装正确

```
$ docker run hello-world
```
### 镜像加速
如果在使用过程中发现拉取 Docker 镜像十分缓慢，可以配置 Docker 国内镜像加速。
### CentOS 7
对于使用 systemd 的系统，请在 /etc/docker/daemon.json 中写入如下内容（如果文件不存在请新建该文件）

```
{
  "registry-mirrors": [
    "https://dockerhub.azk8s.cn",
    "https://reg-mirror.qiniu.com"
  ]
}
```


### 添加内核参数

如果在 CentOS 使用 Docker CE 看到下面的这些警告信息：

```
WARNING: bridge-nf-call-iptables is disabled
WARNING: bridge-nf-call-ip6tables is disabled
```

请添加内核配置参数以启用这些功能。

```
$ sudo tee -a /etc/sysctl.conf <<-EOF
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
EOF
```

然后重新加载 sysctl.conf 即可

```
$ sudo sysctl -p
```




<h1 id="镜像常用命令">镜像常用命令</h1>

#### 搜索镜像

```
docker search [OPTIONS] TERM  
#stars列出star数量不低于
#只列出自动构建的镜像
#
例如:　docker search --filter=stars=200 --filter=is-automated=false --limit=1 mysql
```

![image.png](https://img.hacpai.com/file/2019/11/image-9cc71c59.png)


#### 下载镜像

```
docker pull [选项] [Docker Registry 地址[:端口号]/]仓库名[:标签]

例如: 
1. 拉取官方: docker pull mysql
2. 从阿里云: docker pull registry.cn-hangzhou.aliyuncs.com/hiyzx/nginx_images:zeroNginx
```
- Docker 镜像仓库地址：地址的格式一般是 <域名/IP>[:端口号]。默认地址是 Docker Hub。
- 仓库名：如之前所说，这里的仓库名是两段式名称，即 <用户名>/<软件名>。对于 Docker Hub，如果不给出用户名，则默认为 library，也就是官方镜像。


#### 列出镜像

```
docker images [镜像名称] [--digests]

```
![image.png](https://img.hacpai.com/file/2019/11/image-3db1ed6b.png)


#### 查看镜像大小

```
docker system df
```
![image.png](https://img.hacpai.com/file/2019/11/image-6bad4afe.png)


#### 删除本地镜像

```
docker rmi image
# -f 强制删除
例如: docker rmi -f nginx
```

#### 批量删除

```
$ docker image rmi $(docker image ls -q redis)
```
### 制作镜像
1. 编写Dockerfile

```
# 以nginx为基础，在其上进行定制
FROM nginx
#　执行命令行命令
RUN echo '<h1>Hello, Docker!</h1>' > /usr/share/nginx/html/index.html
```

##### 普通spring-boot应用

```
FROM java:8
ADD target/notice.jar notice.jar
EXPOSE 8080
ENTRYPOINT ["java","-jar","notice.jar"]
```

2. 执行命令

```
docker build -t nginx:v3 .
```
![image.png](https://img.hacpai.com/file/2019/11/image-22edc39f.png)


#### Dockerfile指定详解



<h1 id="容器常用命令">容器常用命令</h1>

#### 创建数据卷

```
#创建一个数据卷，根据Docker最佳实践，容器需要持久化的数据都应该存储在数据卷上
docker volume create mysql
```

#### 运行容器

```
# --rm 说明容器用完就销毁，因为我们的数据都是存储在数据卷上，所以容器停止运行后可以直接把它删除就行了
# --name 容器运行的名称
# -d 是说让我们的容器在后台运行
# -e 给新创建的数据库设置root密码
# -v 把容器中的/var/lib/mysql映射到数据卷上
# -p 23333:3306 把所有对宿主机23333端口的tcp报文转发到容器的3306端口
docker run --rm --name zeroMysql -d -e MYSQL_ROOT_PASSWORD=123456 -v mysql:/var/lib/mysql  -p 3306:3306 mysql
```

#### 启动容器

```
docker start 容器id
```

#### 列出容器

```
docker ps
```

#### 停止容器

```
docker stop 容器id
```

#### 强制停止容器

```
docker kill 容器id
```
#### 进入容器

```
#　如果从这个 stdin 中 exit，不会导致容器的停止
docker exec -it 容器id /bin/bash
```

#### 删除容器

```
# 删除单个
docker rm 容器id
# 删除全部
docker rm $(docker ps -aq)
```

# 仓库

### 阿里云镜像

#### 上传镜像
1. 进入阿里云https://dev.aliyun.com/search.html, 开通镜像服务,设置密码
2. 本地登录: docker login --username=tb0341357 registry.cn-hangzhou.aliyuncs.com
3. 打包镜像: docker tag 5a9061639d0a registry.cn-hangzhou.aliyuncs.com/hiyzx/nginx_images:zeroNginx
4. 推送镜像: docker push registry.cn-hangzhou.aliyuncs.com/hiyzx/nginx_images:zeroNginx

#### 下载镜像
1. 本地登录: docker login --username=tb0341357 registry.cn-hangzhou.aliyuncs.com
2. 拉取镜像: docker pull registry.cn-hangzhou.aliyuncs.com/hiyzx/nginx_images:zeroNginx
3. 启动容器

### 私有仓库(待定)

# 数据管理

![image](38A9D223813E45B0A7F10FA2743C55C6)

## 数据卷
数据卷 的使用，类似于 Linux 下对目录或文件进行 mount，镜像中的被指定为挂载点的目录中的文件会隐藏掉，能显示看的是挂载的 数据卷

### 特性:
1. 数据卷 可以在容器之间共享和重用
2. 对 数据卷 的修改会立马生效
3. 对 数据卷 的更新，不会影响镜像
4. 数据卷 默认会一直存在，即使容器被删除

##### 创建数据卷

```
docker volume create my-vol
```
##### 列出所有

```
docker volume ls
```
##### 查看具体数据卷

```
docker volume inspect mysql
```

##### 删除数据卷

```
# 删除指定的数据卷
docker volume rm mysql
# 删除无主的数据卷
docker volume prune
```
数据卷 是被设计用来持久化数据的，它的生命周期独立于容器，Docker 不会在容器被删除后自动删除 数据卷，并且也不存在垃圾回收这样的机制来处理没有任何容器引用的 数据卷。如果需要在删除容器的同时移除数据卷。可以在删除容器的时候使用 docker rm -v 这个命令。

## 挂载主机目录

```
docker run -d -P  --name web 
    # -v /src/webapp:/opt/webapp 
    --mount type=bind,source=/src/webapp,target=/opt/webapp  training/webapp  python app.py
```
上面的命令加载主机的 /src/webapp 目录到容器的 /opt/webapp目录。这个功能在进行测试的时候十分方便，比如用户可以放置一些程序到本地目录中，来查看容器是否正常工作。本地目录的路径必须是绝对路径，以前使用 -v 参数时如果本地目录不存在 Docker 会自动为你创建一个文件夹，现在使用 --mount 参数时如果本地目录不存在，Docker 会报错。

# 网络

```
# -P 随机端口
docker run --rm --name nginx -d -P nginx

# 指定端口和ip
docker run --rm --name nginx -d -p 127.0.0.1:80:80 nginx
```


